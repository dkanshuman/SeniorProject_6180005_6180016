<?php 

    date_default_timezone_set("Asia/Bangkok");

    // Set the database variable
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "autoexam";

    $sitename = "Auto Exam Generator";