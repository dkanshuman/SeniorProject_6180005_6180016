
<footer>
    <div class="container">
        <p>Copyright &copy;
            <?=  date('Y');?> -
            <?= $sitename; ?>
        </p>
        <a href="index.php#header" class="go-up"><i class="fa-solid fa-angle-up"></i></a>
    </div>
</footer>

</body>

</html>